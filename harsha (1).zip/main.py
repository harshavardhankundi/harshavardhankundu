def name():
    print("civil is a good class")
    
#calling
name()
name()
name()
name()
name()
name()
